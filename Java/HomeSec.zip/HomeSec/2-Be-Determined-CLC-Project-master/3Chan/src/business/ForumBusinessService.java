package business;

public class ForumBusinessService {

}
