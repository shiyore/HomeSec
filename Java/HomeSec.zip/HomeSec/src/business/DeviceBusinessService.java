package business;

import data.DeviceDataService;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import beans.*;

public class DeviceBusinessService {
	public DeviceDataService service = new DeviceDataService();
	
	//returns whether the code was a valid code
	public boolean codeCheck(int code) {
		return service.codeCheck(code);
	}
	
	//adds a new item to the history "table"
	public void addToHistory(int id, String dateTime , int code) {
		service.addToHistory(id, dateTime, code);
	}
	
	//adds a new device item to the device history "table"
	public void addToSensorHistory(int deviceID, String dateTime,  String data) {
		service.addToSensorHistory(deviceID, dateTime, data);
	}
	
	public void tripAlarm() {
		service.tripAlarm();
	}
	
	//Pacifies the alarm
	public void resetAlarm() {
		service.resetAlarm();
	}
	
	//returns true or false for whether the alarm has been tripped
	public boolean alarmStatus() {
		return service.alarmStatus();
	}
	
	//returns all codes
	public List<Code> getCodes(){
		return service.getCodes();
	}
	
	//creates a new code in the db
	public void newCode(Code code) {
		service.newCode(code);
	}
}
