package business;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import beans.History;
import data.DeviceDataService;

@Stateless
@Local(HistoryBusinessInterface.class)
@Alternative
public class HistoryBusinessService implements HistoryBusinessInterface{
	
	//@EJB
	DeviceDataService service = new DeviceDataService();
	
	public List<History> history = new ArrayList<History>();

	public HistoryBusinessService() {
		
	}

	@Override
	public void test() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<History> getHistory() {
		// TODO Auto-generated method stub
		history = service.getHistory();
		return service.getHistory();
	}

}
