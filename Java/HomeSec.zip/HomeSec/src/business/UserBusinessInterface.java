package business;
import java.util.List;

import javax.ejb.Local;

import beans.User;

@Local
public interface UserBusinessInterface {
	public void test();

    //the usual getters and setters
	public void setFirstName(String name);
	public void setLastName(String name);
	public void setUsername(String name);
    public void setPassword(String pword);
    public void setPhone(String number);
    public void setAddress(String address);
    
    public String getFirstName();
    public String getLastName();
    public String getUsername();
    public String getPassword();
    public String getPhone();
    public String getAddress();
    
    public boolean userLogin(String username, String password);
}
