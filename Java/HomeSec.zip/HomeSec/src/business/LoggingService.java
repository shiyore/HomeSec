package business;


import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Interceptor
public class LoggingService {
	private Logger logger = LoggerFactory.getLogger(LoggingService.class);
	  
	  public Object error(InvocationContext context ) throws Exception{
		  logger.error("Error with " + context.getMethod().getName());
		  return context.proceed();
	  }
	  public Object warn(InvocationContext context ) throws Exception{
		  logger.warn("Potential error with " + context.getMethod().getName());
		  return context.proceed();
	  }
	  public Object debug(InvocationContext context ) throws Exception{
		  logger.debug(context.getMethod().getName() + " has been run.");
		  return context.proceed();
	  }
	  
	  @AroundInvoke
	  public  Object info(InvocationContext context ) throws Exception{
		  logger.info(context.getMethod().getName() + " has been run.");
		  return context.proceed();
	  }

}
