package business;
import java.util.List;

import javax.ejb.Local;

import beans.History;

@Local
public interface HistoryBusinessInterface {
	public void test();
	public List<History> getHistory();
}
