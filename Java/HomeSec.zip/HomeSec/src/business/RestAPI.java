package business;

import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.json.Json;
import javax.json.JsonObject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import business.DeviceBusinessService;

@RequestScoped
@Path("/API")
@Produces({ "application/xml", "application/json" })
@Consumes({ "application/xml", "application/json" })
public class RestAPI {
	
	DeviceBusinessService service = new DeviceBusinessService();
	
	@GET
	@Path("/codeCheck/{id}/{code}/{dateTime}")
	@Produces (MediaType.APPLICATION_JSON)
	@Interceptors(LoggingService.class)
	public JsonObject codeCheck(@PathParam("id") Integer id,@PathParam("code") int code,@PathParam("dateTime") String dateTime){
		
		//adds the code to the history, then resets the alarm
		service.addToHistory(id,dateTime,code);
		boolean check = service.codeCheck(code);
		if (check)
			service.resetAlarm();
		
		JsonObject value = Json.createObjectBuilder()
			     .add("ValidCode", check)
			     .build();
		return value;
	}
	
	@POST
	@Path("/sensorTrip/{id}/{date}/{data}")
	@Produces (MediaType.APPLICATION_JSON)
	@Interceptors(LoggingService.class)
	public Response sensorTrip(@PathParam("id") Integer id,@PathParam("date") String date, @PathParam("data") String data){
		
		//adds the data to the sensor history "table" then sets the alarm to true
		service.addToSensorHistory(id, date, data);
		service.tripAlarm();
		
		String message = "The sensor history has been updated and the data alarm set to true";
		 
		return Response
				.status(Response.Status.OK)
				.entity(message)
				.type(MediaType.TEXT_PLAIN)
				.build();
	}
	
	@GET
	@Path("/alarmStatus")
	@Produces (MediaType.APPLICATION_JSON)
	@Interceptors(LoggingService.class)
	public JsonObject alarmStatus(){
		
		//adds the code to the history, then resets the alarm
		boolean check = service.alarmStatus();
		
		JsonObject value = Json.createObjectBuilder()
			     .add("AlarmTripped", check)
			     .build();
		return value;
	}
	
}
