package business;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import beans.User;
import data.UserDataService;

/**
 * This is our EJB for users
 */
@Stateless
@Local(UserBusinessInterface.class)
@LocalBean
@Alternative
public class UserBusinessService implements UserBusinessInterface{

    /**
     * Default constructor. 
     */
	@EJB
	UserDataService service = new UserDataService();
	
	User user;
    public UserBusinessService() {
        // TODO Auto-generated constructor stub
    	user = new User();
    	
    }

	/**
     * @see OrdersBusinessInterface#test()
     */
    public void test() {
        // TODO Auto-generated method stub
    	//System.out.println("Hello from the other side");
    }

    //the usual getters and setters
    public void setFirstName(String name) {
		user.setFirstName(name);
	}
    public void setPassword(String pword) {
		user.setPassword(pword);
	}
    
    public String getName() {
		return user.getFirstName() + " " + user.getLastName();
	}
    public String getPassword() {
		return user.getPassword();
	}

	@Override
	public void setLastName(String name) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setUsername(String name) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setPhone(String number) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setAddress(String address) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getFirstName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getLastName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getPhone() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getAddress() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public boolean userLogin(String username, String password) {
		return service.loginCheck(username, password);
	}

}
