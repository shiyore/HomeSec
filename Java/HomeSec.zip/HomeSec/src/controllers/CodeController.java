package controllers;

import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import beans.Code;
import beans.History;
import beans.User;
import business.DeviceBusinessService;
import business.HistoryBusinessInterface;
import java.io.Serializable;
import javax.enterprise.context.Dependent;

@Named("CodeController")
@Dependent
public class CodeController implements Serializable {
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	DeviceBusinessService service = new DeviceBusinessService();
	 
	 public String onSubmit(User user) {
	        
	        service.getCodes();
	        FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
	        FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("codes", service.getCodes().toArray(new Code[0]));
	        return "AllCodes.xhtml";        
	    }
	 public String newCode(Code code) {
		 service.newCode(code);
		 service.getCodes();
	        FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("code", code);
	        FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("codes", service.getCodes().toArray(new Code[0]));
	        return "AllCodes.xhtml";
	 }
}
