package controllers;


import beans.User;
import business.UserBusinessInterface;
import business.UserBusinessService;

import java.util.List;


import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import java.io.Serializable;

@Named("formController")
@ViewScoped
public class FormController implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//User user;
	
	
	public String onSubmit(User user) {
		//Forward to Test Response View along with the User Managed Bean
		//System.out.println("onSubmit " + user.getFirstName() + user.getPassword());
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
		UserBusinessService business = new UserBusinessService();
		if(business.userLogin(user.getFirstName(), user.getPassword()))
			return "LoginResponse.xhtml";
		return "LoginFail.xhtml";
	}
	
	
}
