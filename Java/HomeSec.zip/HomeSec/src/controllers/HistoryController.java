package controllers;

import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import beans.History;
import beans.User;
import business.HistoryBusinessInterface;
import java.io.Serializable;
import javax.enterprise.context.Dependent;

@Named("HistoryController")
@Dependent
public class HistoryController implements Serializable {
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Inject 
	HistoryBusinessInterface service;
	 
	 public String onSubmit(User user) {
	        
	        service.getHistory();
	        FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
	        FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("history", service.getHistory().toArray(new History[0]));
	        return "History.xhtml";        
	    }
}
