package controllers;

import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import beans.User;
import business.HistoryBusinessInterface;
import java.io.Serializable;

@Named("historyController")
@ViewScoped
public class HistoryController implements Serializable {
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Inject 
	 HistoryBusinessInterface service;
	 
	 public String onSubmit(User user) {
	        
	        service.getHistory();
	        FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
	        return "History.xhtml";        
	    }
}
