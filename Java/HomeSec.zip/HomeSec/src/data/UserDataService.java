package data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.io.File;  // Import the File class
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.util.Scanner; // Import the Scanner class to read text files

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import beans.User;
@Stateless
@Local(DataAccessInterface.class)
@LocalBean
public class UserDataService extends database implements DataAccessInterface<User>
{
	
	public UserDataService()
	{
		
	}

	@Override
	public List<User> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean create(User t) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(User t) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(User t) {
		// TODO Auto-generated method stub
		return false;
	}

	public User findPost(int id) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public boolean loginCheck(String username, String password){
		Connection conn = null;
		try {
			//attempt a connection
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/homesecserv","root","root");
			
			Statement stmt = null;
			ResultSet rs = null;
			String sql = "SELECT * FROM users WHERE username='"+username+"' AND password='"+password+"'";

			try {
				stmt = conn.createStatement();
				rs = stmt.executeQuery(sql);

				if (stmt.execute(sql)) {
					rs = stmt.getResultSet();
				}
				
				if(rs.next()) {
					return true;
				}
				return false;
			} catch (SQLException ex) {
				// handle any errors
				System.out.println("SQLException: " + ex.getMessage());
				System.out.println("SQLState: " + ex.getSQLState());
				System.out.println("VendorError: " + ex.getErrorCode());
			} finally {

				if (rs != null) {
					try {
						rs.close();
					} catch (SQLException sqlEx) {
					} // ignore

					rs = null;
				}

				if (stmt != null) {
					try {
						stmt.close();
					} catch (SQLException sqlEx) {
					} // ignore

					stmt = null;
				}
			}

		} catch (SQLException ex) {
			// handle any errors
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
		}
	
		return false;

	}
	
}
