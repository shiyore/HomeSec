package data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.io.File;  // Import the File class
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.util.Scanner; // Import the Scanner class to read text files

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import beans.User;
@Stateless
@Local(DataAccessInterface.class)
@LocalBean
public class UserDataService extends database implements DataAccessInterface<User>
{
	
	public UserDataService()
	{
		
	}

	@Override
	public List<User> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean create(User t) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(User t) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(User t) {
		// TODO Auto-generated method stub
		return false;
	}

	public User findPost(int id) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public boolean loginCheck(String username, String password){
		//as of 06/14 the MySQL database still isn't working the Java EE, so the following 2 lines will be commented until then
		super.sql = "SELECT * FROM `users` WHERE username='"+username+"' AND password='"+password+"' ";
		super.query();
		
		/**String[] user;
		File userFile = new File("C:\\HomeSec\\homesec_serv\\users.txt");
	    try {
			Scanner myReader = new Scanner(userFile);
			user = myReader.nextLine().split("\\|");
			System.out.println(user[0] + " " + user[1]);
			if (user[0].equals(username) && user[1].equals(password))
				return true;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}**/
		
		
		return false;
	}
	
}
