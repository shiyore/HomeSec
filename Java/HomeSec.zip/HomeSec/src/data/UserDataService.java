package data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import beans.User;
@Stateless
@Local(DataAccessInterface.class)
@LocalBean
public class UserDataService extends database implements DataAccessInterface<User>
{
	
	public UserDataService()
	{
		
	}

	@Override
	public List<User> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean create(User t) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(User t) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(User t) {
		// TODO Auto-generated method stub
		return false;
	}

	public User findPost(int id) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public boolean loginCheck(String username, String password){
		super.sql = "SELECT * FROM `users` WHERE username='"+username+"' AND password='"+password+"' ";
		super.query();
		return true;
	}
	
}
