package data;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import beans.Device;
import beans.History;

public class DeviceDataService {

	public boolean codeCheck(int code) {
		ArrayList<String[]> codes = new ArrayList<String[]>();
		
		
		File keysFile = new File("C:\\HomeSec\\homesec\\AccessKeys.txt");
	    try {
			Scanner myReader = new Scanner(keysFile);
			while(myReader.hasNextLine()) {
				codes.add(myReader.nextLine().split("\\|"));
			}
			
			for(String[] codeLine: codes) {
				System.out.println(codeLine[1]);
				if(codeLine[1].equals(""+code))
					return true;
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return false;
	}
	
	public void addToHistory(int id, String dateTime , int code) {
		History item = new History(id, dateTime, code);

		File file = new File("C:\\HomeSec\\homesec\\history.txt");
		FileWriter fr;
		try {
			fr = new FileWriter(file, true);
			BufferedWriter br = new BufferedWriter(fr);
			br.write(item.toString()+"\n");

			br.close();
			fr.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//adds the device to the sensor history
	public void addToSensorHistory(int deviceID, String name, String type, String data) {
		Device sensor = new Device(deviceID, name, type, data);

		File file = new File("C:\\HomeSec\\homesec\\SensorHistory.txt");
		FileWriter fr;
		try {
			fr = new FileWriter(file, true);
			BufferedWriter br = new BufferedWriter(fr);
			br.write(sensor.toString()+"\n");

			br.close();
			fr.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//sets the alarm off
	public void tripAlarm() {
	    try {
			File file = new File("C:\\HomeSec\\homesec\\Alarm.txt");
			FileWriter fr;
			fr = new FileWriter(file, false);
			
			//changes the alarm status in the file
			fr.write("true");
			fr.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//resets the alarm to false
	public void resetAlarm() {
		try {
			File file = new File("C:\\HomeSec\\homesec\\Alarm.txt");
			FileWriter fr;
			fr = new FileWriter(file, false);
			
			//changes the alarm status in the file
			fr.write("false");
			fr.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//same as the function in the business service
	public boolean alarmStatus() {
		String status = "";
		
		File keysFile = new File("C:\\HomeSec\\homesec\\Alarm.txt");
	    try {
			Scanner myReader = new Scanner(keysFile);
			
			status = myReader.nextLine();
			return Boolean.parseBoolean(status);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    return false;
	}
}
