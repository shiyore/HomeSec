package data;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import beans.Device;
import beans.History;

public class DeviceDataService {

	public boolean codeCheck(int code) {
		Connection conn = null;
		try {
			//attempt a connection
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/homesec","root","root");
			
			Statement stmt = null;
			ResultSet rs = null;
			String sql = "SELECT * FROM accesskeys WHERE code='"+code+"'";

			try {
				stmt = conn.createStatement();
				rs = stmt.executeQuery(sql);

				if (stmt.execute(sql)) {
					rs = stmt.getResultSet();
				}
				
				if(rs.next()) {
					return true;
				}
				return false;
			} catch (SQLException ex) {
				// handle any errors
				System.out.println("SQLException: " + ex.getMessage());
				System.out.println("SQLState: " + ex.getSQLState());
				System.out.println("VendorError: " + ex.getErrorCode());
			} finally {

				if (rs != null) {
					try {
						rs.close();
					} catch (SQLException sqlEx) {
					} // ignore

					rs = null;
				}

				if (stmt != null) {
					try {
						stmt.close();
					} catch (SQLException sqlEx) {
					} // ignore

					stmt = null;
				}
			}

		} catch (SQLException ex) {
			// handle any errors
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
		}
	
		return false;
	}
	
	public void addToHistory(int id, String dateTime , int code) {

		Connection conn = null;
		
		//SQL query
		String sql = "INSERT INTO homesec.history(date, code, device) VALUES ('" + dateTime + "', '" + code + "', " + id + ")";
		try
		{
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/homesec","root","root");
			
			Statement stmt = conn.createStatement();
			stmt.executeUpdate(sql);
			stmt.close();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			if(conn != null)
			{
				try
				{
					conn.close();
				}
				catch (SQLException e)
				{
					e.printStackTrace();
				}
			}
		}
	}
	
	//adds the device to the sensor history
	public void addToSensorHistory(int deviceID, String dateTime,  String data) {
		Connection conn = null;
		
		//SQL query
		String sql = "INSERT INTO homesec.history(date, data, device) VALUES ('" + dateTime + "', '" + data + "', " + deviceID + ")";
		try
		{
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/homesec","root","root");
			
			Statement stmt = conn.createStatement();
			stmt.executeUpdate(sql);
			stmt.close();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			if(conn != null)
			{
				try
				{
					conn.close();
				}
				catch (SQLException e)
				{
					e.printStackTrace();
				}
			}
		}
	}
	
	//sets the alarm off
	public void tripAlarm() {
		Connection conn = null;
		
		//SQL query
		String sql = "UPDATE `devicedat` SET `activated`=1 WHERE `deviceType`='alarm_type'";
		try
		{
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/homesec","root","root");
			
			Statement stmt = conn.createStatement();
			stmt.executeUpdate(sql);
			stmt.close();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			if(conn != null)
			{
				try
				{
					conn.close();
				}
				catch (SQLException e)
				{
					e.printStackTrace();
				}
			}
		}
	}
	
	//resets the alarm to false
	public void resetAlarm() {
		Connection conn = null;
		
		//SQL query
		String sql = "UPDATE `devicedat` SET `activated`=0 WHERE `deviceType`='alarm_type'";
		try
		{
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/homesec","root","root");
			
			Statement stmt = conn.createStatement();
			stmt.executeUpdate(sql);
			stmt.close();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			if(conn != null)
			{
				try
				{
					conn.close();
				}
				catch (SQLException e)
				{
					e.printStackTrace();
				}
			}
		}
	}
	
	//same as the function in the business service
	public boolean alarmStatus() {
		Connection conn = null;
		try {
			//attempt a connection
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/homesec","root","root");
			
			Statement stmt = null;
			ResultSet rs = null;
			String sql = "SELECT * FROM devicedat WHERE deviceType='alarm_type'";

			try {
				stmt = conn.createStatement();
				rs = stmt.executeQuery(sql);

				if (stmt.execute(sql)) {
					rs = stmt.getResultSet();
				}
				
				//add all albums to the list
				rs.next();
				return rs.getBoolean("activated");
				
			} catch (SQLException ex) {
				// handle any errors
				System.out.println("SQLException: " + ex.getMessage());
				System.out.println("SQLState: " + ex.getSQLState());
				System.out.println("VendorError: " + ex.getErrorCode());
			} finally {

				if (rs != null) {
					try {
						rs.close();
					} catch (SQLException sqlEx) {
					} // ignore

					rs = null;
				}

				if (stmt != null) {
					try {
						stmt.close();
					} catch (SQLException sqlEx) {
					} // ignore

					stmt = null;
				}
			}

		} catch (SQLException ex) {
			// handle any errors
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
		}
	
		return false;
	}
	
	//reads through the files to get the code input history
	public List<History> getHistory(){
		ArrayList<History> History = new ArrayList<History>();
		
		
		Connection conn = null;
		try {
			//attempt a connection
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/homesec","root","root");
			
			Statement stmt = null;
			ResultSet rs = null;
			String sql = "SELECT * FROM homesec.history";

			try {
				stmt = conn.createStatement();
				rs = stmt.executeQuery(sql);

				if (stmt.execute(sql)) {
					rs = stmt.getResultSet();
				}
				
				//add all albums to the list
				while (rs.next())
				{
					History.add(new History(rs.getInt("device"),rs.getString("date"), rs.getInt("code"), rs.getString("data")));
				}
			} catch (SQLException ex) {
				// handle any errors
				System.out.println("SQLException: " + ex.getMessage());
				System.out.println("SQLState: " + ex.getSQLState());
				System.out.println("VendorError: " + ex.getErrorCode());
			} finally {

				if (rs != null) {
					try {
						rs.close();
					} catch (SQLException sqlEx) {
					} // ignore

					rs = null;
				}

				if (stmt != null) {
					try {
						stmt.close();
					} catch (SQLException sqlEx) {
					} // ignore

					stmt = null;
				}
			}

		} catch (SQLException ex) {
			// handle any errors
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
		}
	
		return History;
	}
}
