package beans;

import javax.faces.bean.ManagedBean;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

@Named("code")
@ViewScoped
public class Code implements Serializable{
	private static final long serialVersionUID = 1L;
	@NotNull(message = "You must fill in the username field.")
	@Size(min=4,max=15)
    String username = "";
	
	@NotNull(message = "You must have a code.")
	@Digits(integer=20, fraction=0)
    int code = 0;

    
    public Code() {
        username = "John";
        code = 111111;
    }
    public Code(String username, int code) {
    	this.username = username;
    	this.code = code;
    }


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public int getCode() {
		return code;
	}


	public void setCode(int code) {
		this.code = code;
	}
    
    
}
