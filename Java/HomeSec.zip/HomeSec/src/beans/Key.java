package beans;

//This is a temporary class until the issues with MySQL are solved. This is used for a access key array that acts as a "table".
public class Key {
	private int id;
	private int code;
	private boolean masterKey;
	private int userID;
	
	
	public Key() {
		id = 0;
		code = 1345123;
		masterKey = false;
		userID = 0;
	}
	
	public Key(int id , int code, boolean masterKey, int userID) {
		this.id = id;
		this.code = code;
		this.masterKey = masterKey;
		this.userID = userID;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public boolean isMasterKey() {
		return masterKey;
	}

	public void setMasterKey(boolean masterKey) {
		this.masterKey = masterKey;
	}

	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}
	
	public boolean verify(int code) {
		if (this.code == code)
			return true;
		return false;
	}
	
	//for adding a new key/updating one with the temporary file system
	@Override
	public String toString() {
		return id + "|" + code +"|" + masterKey + "|" + userID;
	}
	
}
