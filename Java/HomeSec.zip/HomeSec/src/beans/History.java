package beans;

import java.time.LocalTime;

public class History {
	private String dateTime;
	private int code;
	private int deviceID;
	private String data;
	
	public History() {
		deviceID = 0;
		dateTime = LocalTime.now().toString();
		code = 0000000000;
	}
	public History(int deviceID, String dateTime, int code, String data) {
		this.deviceID = deviceID;
		this.dateTime = dateTime;
		this.code = code;
		this.setData(data);
	}
	
	public String getDateTime() {
		return dateTime;
	}
	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public int getDeviceID() {
		return deviceID;
	}
	public void setDeviceID(int deviceID) {
		this.deviceID = deviceID;
	}
	
	//this is to output into the temporary history.txt file
	@Override
	public String toString() {
		return deviceID + "|" + dateTime + "|" + code ;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	
}
